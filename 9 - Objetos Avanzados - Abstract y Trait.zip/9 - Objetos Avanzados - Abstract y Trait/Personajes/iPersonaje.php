<?php

 interface iPersonaje {

public function atacar();
public function defender();

}

?>